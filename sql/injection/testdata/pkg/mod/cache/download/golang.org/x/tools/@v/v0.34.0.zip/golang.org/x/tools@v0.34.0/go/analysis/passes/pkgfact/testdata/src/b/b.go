package b

import _ "a"

const _pi_ = 3.14159
